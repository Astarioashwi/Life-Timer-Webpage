let isDOBOpen = false;

const settingCogE1 = document.getElementById("settingIcon");
const settingContentE1 = document.getElementById("settingContent");


const toggleDataOfBirthSelector = () => {

}